function fig_dir = get_fig_dir

fig_dir = [ get_proj_root_dir '/kappa_figures' ];
