figure(1); clf; 

fig_file_name = strrep(kappa_fig_title,' ','_');
fig_file_name = strrep(fig_file_name,')','');
fig_file_name = strrep(fig_file_name,'(','');

subplot(2,1,1)
colormap([1 0 0; [0 1 0]; 0 0 1])
geoscatter( raw.lat, raw.lon, 30, raw.val, 'filled' )
k = find( raw.is_robust == 0 );
geolimits([-35 45],[-180 180])
caxis([-2 2])
sgtitle([ '    ' kappa_fig_title], 'fontSize',20,'fontWeight','bold')
title('Original sites','fontSize',16)

subplot(2,1,2)
geoscatter( grid.lat, grid.lon, 30, grid.val, 'filled' )
hold on
geolimits([-35 40],[-180 180])
caxis([-2 2])
title({ [ 'Merged sites (' num2str(terr_rad) ' km radius)' ] },'fontSize',16)

set(gcf,'PaperPositionMode','auto')
set(gcf,'Position',[ 150 150 1000 420 ])
set(gcf,'PaperOrientation','Portrait')

pdf_file = sprintf('%s/sites_%s_grid_%s.pdf',get_fig_dir,proxy_type_desc,fig_file_name);

oldunits = get(gcf,'Units');
set(gcf, 'PaperUnits', 'centimeters', 'Units', 'centimeters');
figpos = get(gcf, 'Position');
set(gcf, 'PaperSize', figpos(3:4), 'Units', oldunits);
print(gcf, '-dpdf', pdf_file,'-bestfit');


