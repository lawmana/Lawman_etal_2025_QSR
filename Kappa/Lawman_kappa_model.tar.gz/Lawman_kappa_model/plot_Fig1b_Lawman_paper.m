clear
%
compilation_version = '2025';
orig_interp_drywet = 0;
proxy_type_desc = 'all';

pmip_clim_dir = get_proj_root_dir;
proxy_dir = get_proj_root_dir;
data_dir = [  get_proj_root_dir '/kappa_data' ];

plot_perLim = [ 1 65 ];
dPP_lim = 1 : 1 : 100; % thresholds used to define dry/unch/wet categories
ax = [];

letter_label_list = { 'b' };
figure(2); clf
set(gcf,'Position',[ 1 55 1450 780])

region_name = 'Global';
kappa_fig_title = 'Global';

subplot_i = [ 1 ];

model_ta_cooling = load('ta_cooling_models_2025.mat');
[ model_ta_cooling_sorted, l ] = sort(model_ta_cooling.ta_cooling);
model_name_list = model_ta_cooling.model_name_list(l);
model_name_list_label = model_ta_cooling.model_name_list_label(l);
for m = 1 : length(model_name_list_label)
	model_name_list_label{m} = [ num2str(m) '.' model_name_list_label{m} ];
	model_name_list_label_num{m} = [ num2str(m) ];
end

model_name_list_b = model_name_list;
model_name_list_label_b = model_name_list_label;
model_name_list_label_num_b = model_name_list_label_num;
model_name_list = {};
model_name_list_label = {};
model_name_list_label_num = {};

trop_cooling_ensembles = { 'MMEM-TATLCooling' 'MMEM-NoTATLCooling' };
trop_cooling_ensembles_ranges = { [ -inf -1 ] [ -1 inf ] };

for ll = 1:length(trop_cooling_ensembles)

	cooling_r = trop_cooling_ensembles_ranges{ll};
	mm = find( model_ta_cooling_sorted > cooling_r(1) & model_ta_cooling_sorted < cooling_r(2) );
	model_name_list = [ model_name_list {model_name_list_b{mm}} trop_cooling_ensembles{ll} 'empty' ];
	model_name_list_label = [ model_name_list_label {model_name_list_label_b{mm}} 'Ensemble mean' {''} ];
	model_name_list_label_num = [ model_name_list_label_num {model_name_list_label_num_b{mm}} 'EM' {''} ];
end
model_name_list = {model_name_list{1:end-1}};
model_name_list_label = {model_name_list_label{1:end-1}};

% this mat file is used in the spider plots
if orig_interp_drywet
	file_desc_add = 'origdrywet';
else
	file_desc_add = 'newdrywet';
end
kappa_mat_file = sprintf('%s/%s_%s_%s_kappa.mat',data_dir,region_name,proxy_type_desc,file_desc_add);

load(kappa_mat_file,'all_kappa','all_kappa_p','all_kappa_sig','model_name_list','model_name_list_label','ta_cooling','grid','dPPi_all','raw')
k = find( all_kappa < 0 );
all_kappa(k) = 0;
all_kappa_p(k) = 1;
all_kappa_sig(k) = 0;

plot_i = 1;

figure(2);
ax(plot_i) = subplot(3,2,plot_i);
plot_model_name_labels = 0;
if plot_i <=2
	plot_model_name_labels = 1;
end

plot_kappa_thresholds

title(kappa_fig_title,'fontSize',16)
text(-2.3,69.5,letter_label_list{1},'fontSize',20)
axPos(plot_i,:) = get(ax(plot_i),'Position');


figure(2);
set(gcf,'Position',[ 1         555        1112         800 ])
pdf_file = sprintf('%s/Figure1b.pdf',get_paper_fig_dir);
exportgraphics(gcf,pdf_file,'BackgroundColor','none','ContentType','vector')
