function [ dvarp, lon, lat, dvarpi, dvar, tas_data, amoc_data ] = get_model_lgm_var_change_2024( model, model_clim, var_name, plat, plon, dvarp_lim, dPP_norm )
%
	dvarp = [];
	lon = [];
	lat = [];
	dvarpi = [];
	dvar = [];
	tas_data = [];
	amoc_data = [];

	[ pr_hose, pr_ctl, tas_hose, tas, lon, lat, model_list, del, lgm_amoc, hose_amoc ] = get_hose_data_new;

	load('ta_cooling_models_2025.mat');

	for ll = 1:length(trop_cooling_ensembles)
		if strcmp(trop_cooling_ensembles{ll},model)
        		cooling_r = trop_cooling_ensembles_ranges{ll};
        		mm_b = find( ta_cooling > cooling_r(1) & ta_cooling < cooling_r(2) );
		end
	end

	switch model
		case { 'MMEM-TATLStrongCooling' 'MMEM-TATLModCooling' 'MMEM-NoTATLCooling' 'MMEM-TATLCooling' }
			mm = mm_b;
		case { 'empty' }
			mm = [];
		otherwise
			mm = [];
			for l = 1 : length( model_list )
				if strcmp(model_list{l},model)
					mm = [ l l ];
				end
			end
	end
	disp( [ 'reading ' model_list{mm} ' data' ])

	tas_data.ta_cooling = ta_cooling(mm);
	amoc_data.lgm_amoc = lgm_amoc(mm);
	amoc_data.hose_amoc = hose_amoc(mm);

	% fix some big numbers close to the poles
	k = find( abs(pr_hose) > 1e10 );
	pr_hose(k) = NaN;

	var_ctl = squeeze(nanmean(pr_ctl(mm,:,:)));
	var_hose = squeeze(nanmean(pr_hose(mm,:,:))) + var_ctl;
	dvar = var_hose;

	if dPP_norm
		dvarp = ( var_hose - var_ctl )./var_ctl;
		dPP_factor = 100;
	else
		dvarp = ( var_hose - var_ctl );
		dPP_factor = 1;
	end

	dvarp = dvarp.*dPP_factor;

	dvarpi = [];

        for l = 1 : length( dvarp_lim )
		[ lon2, lat2 ] = meshgrid(lon,lat);
		aux = interp2( lon2, lat2, dvarp', plon, plat, 'linear' );
                k = find( abs(aux) < dvarp_lim(l) );
                aux(k) = 0;
                aux = sign(aux);
                dvarpi(l,:) = aux;
        end

	if strcmp(model,'empty') & isempty(mm)
		tas_data.ta_cooling = NaN;
		var_ctl = squeeze(pr_ctl(1,:,:)).*NaN;
		var_hose = squeeze(pr_hose(1,:,:))*NaN;
		dvar = var_hose;
                aux = aux.*NaN;
                dvarpi = dvarpi.*NaN;
	end
