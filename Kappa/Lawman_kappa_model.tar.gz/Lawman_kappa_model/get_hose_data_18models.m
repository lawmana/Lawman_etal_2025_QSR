function [ pr_hose, pr, tas_hose, tas, lon, lat, model_name_list, model_name_list_label, lgm_amoc, hose_amoc, fw ] = get_hose_data_new
% [ pr_hose, pr, tas_hose, tas, lon, lat, model_name_list, model_name_list_label, lgm_amoc, hose_amoc, fw ] = get_hose_data_new

nc_file = [ get_pmip_clim_dir '/Regridded_tas_18models.nc'];
lon = ncread(nc_file,'lon');
lat = ncread(nc_file,'lat');
tas_hose = ncread(nc_file,'hose');
tas = ncread(nc_file,'control');
tas_hose = permute(tas_hose,[ 3 1 2 ]);
tas = permute(tas,[ 3 1 2 ]);

nc_file = [ get_pmip_clim_dir '/Regridded_precip_18models.nc'];
lon = ncread(nc_file,'lon');
lat = ncread(nc_file,'lat');
pr_hose = ncread(nc_file,'hose');
pr = ncread(nc_file,'control');
pr_hose = permute(pr_hose,[ 3 1 2 ]);
pr = permute(pr,[ 3 1 2 ]);

fid = fopen([ get_pmip_clim_dir '/Regridded_model_names_18models.txt']);
model_info = textscan(fid,'%s\t%f\t%f\t%f\n');
fclose(fid);

model_name_list = model_info{1};
model_name_list_label = model_name_list;
lgm_amoc = model_info{2};
hose_amoc = model_info{3};
fw = model_info{4};
