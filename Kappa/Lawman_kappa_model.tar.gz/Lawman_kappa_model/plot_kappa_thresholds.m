
l = pcolor(.5:length(model_name_list)+.5,dPP_lim,[ all_kappa; all_kappa(end,:)]');
set(l,'edgecolor','none')
caxis(1./100*[.1 69.9])
set(gca,'yTick',0:10:100)
set(gca,'xTick',1:1:length(model_name_list))
set(gca,'yLim',plot_perLim)
%ylabel([ '\Delta' var_name ' (%)'],'fontSize',14)
ylabel( { 'drier/wetter threshold' '% rainfall change'},'fontSize',14)
set(gca,'yTick',0:10:100)
set(gca,'lineWidth',1)
if ~plot_model_name_labels
	set(gca,'xTick',1:22);
	set(gca,'xTickLabel',model_name_list_label_num,'fontSize',10)
	set(gca,'XTickLabelRotation',60)
	hl = rotateticklabel(gca,40);
	set(hl,'fontSize',8)
else
	set(gca,'xTickLabel',model_name_list_label,'fontSize',10)
	hl = rotateticklabel(gca,40);
	for l = 1 : length(hl)
		pos = get(hl(l),'Position');
		set(hl(l),'Position',pos + [ 0 .1 0 ])
		set(hl(l),'fontSize',8)
		if l <= length(ta_cooling)
			if ta_cooling(l) ~=0 & ~isnan(ta_cooling(l))
			switch model_name_list{l}
				case 'CCSM_NCAR--'
					label_pos_y = 2;
				case 'COSMOS_S--'
					label_pos_y = 4;
				otherwise
					label_pos_y = 3;
			end
			%text(l+.03,label_pos_y,sprintf('%.1f',ta_cooling(l)),'fontSize',9,'Color',0*[1 1 1],'horizontalAlignment', 'center')
			end
		end
	end
end
box on
set(gca, 'Layer', 'top')
set(gca,'tickLength',[0 0])
set(gca,'lineWidth',1)
if plot_model_name_labels
	text(3,-38,{ 'Models with strong and moderate' 'tropical Atlantic cooling' },'fontSize',10, 'horizontalAlignment', 'center','fontWeight','bold')
	text(15.5,-38,{ 'Models with negligible' 'tropical Atlantic cooling' },'fontSize',10, 'horizontalAlignment', 'center','fontWeight','bold')
end
%if ~plot_model_name_labels
%	set(gca,'xTickLabels',[])
%end

hold on
for m = 1 : length(model_name_list)
	k = find(all_kappa_sig(m,:)==1);
	if ~isempty(k)
		k = k(end);  
		h = bar(m,dPP_lim(k),1,'LineWidth',2,'FaceColor','none');
	end
end

%corrcoef(all_kappa(:).*100,all_per(:))


% colorbar
cbar = colorbar;
ylabel(cbar,'Cohen''s \kappa','fontSize',18)
cbarPos = get(cbar,'Position');
cbarPos(3) = .02;
%cbarPos(1) = cbarPos(1)+.065;
%set(cbar,'Position',cbarPos)
set(cbar,'fontSize',14)

colormap('default');
cmap = colormap('hot');
cmap = flipud(cmap);
cmap = cmap(1:end-15,:);
colormap(cmap);
set(cbar,'yTick',.1:.1:.9)
set(gca,'lineWidth',1)
set(gca,'fontSize',14)

set(gcf,'PaperPositionMode','auto')
set(gcf,'Position',[ 150 150 680 700 ])
set(gcf,'PaperOrientation','Portrait')

kappa_fig_file_name = strrep(kappa_fig_title,' ','_');
kappa_fig_file_name = strrep(kappa_fig_file_name,')','_');
kappa_fig_file_name = strrep(kappa_fig_file_name,'(','_');
