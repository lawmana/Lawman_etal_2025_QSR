function model_dir = get_pmip_clim_dir

model_dir = [ get_proj_root_dir ];
