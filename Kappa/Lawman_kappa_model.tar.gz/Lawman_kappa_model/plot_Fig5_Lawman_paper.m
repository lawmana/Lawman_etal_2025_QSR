clear

alpha_kappa_3s = .01; % only regional kappa with 1-alpha significance are plotted
alpha_kappa_2s = .05; % only regional kappa with 1-alpha significance are plotted
alpha_kappa_1s = .33; % only regional kappa with 1-alpha significance are plotted

proxy_type_desc = 'all';

cat_drywet = 'orig';
cat_drywet = 'new';

proxy_type_desc_list = { 'all' 'nomariso' 'aridity_terriso' 'terriso_veg' 'aridity_veg' };
proxy_type_desc_label_list = { 'All proxy types' {'All excluding' '\delta^{18}O_{sw}'} { 'Terrestrial isotopes' '& Aridity' } ...
	{ 'Terrestrial isotopes' '& Vegetation' } { 'Aridity &' 'Vegetation' } };

region_list = { 'Global' 'AtlanticITCZ' 'GlobalNoAtlanticITCZ' 'PacificITCZ' 'WalkerCirculation' 'IOMonsoons' };
region_list_title = { 'Global' 'Atlantic ITCZ' 'Caribbean and Eastern Pacific ITCZ' 'Pacific Walker Circulation' 'East African, Indian, and Australian Monsoons' };
region_list_label = { 'Global Tropics' 'Atlantic ITCZ' '    Global Tropics\newline (excl. Atlantic ITCZ)' '   Caribbean and\newline Eastern Pacific ITCZ' 'Pacific Walker Circulation' '    East African, Indian,\newline and Australian Monsoons' };

region_list = { 'Global' 'AtlanticITCZ' 'GlobalNoAtlanticITCZ' };
region_list_label = { 'Global Tropics' 'Atlantic ITCZ' '    Global Tropics\newline (excl. Atlantic ITCZ)' };
kappa_by_region_and_model_1s_all = [];

figure(1); clf

for nn = 1 : length(region_list)

	region_name = region_list{nn};

	plot_1s = 1;

	dPP_lim = 1 : 1 : 100;
	minDPlim = 5;

	data_dir = './kappa_data/';

	kappa_by_region_and_model_1s = [];
	kappa_by_region_and_model_2s = [];
	kappa_by_region_and_model_3s = [];

	for mm = 1:length(proxy_type_desc_list)

		proxy_type_desc = proxy_type_desc_list{mm};

		kappa_mat_file = sprintf('%s/%s_%s_%sdrywet_kappa.mat',data_dir,region_name,proxy_type_desc,cat_drywet);
		load(kappa_mat_file)
		ii = find( dPP_lim < minDPlim );
		all_kappa(:,ii) = NaN;

		all_kappa_1s = all_kappa;
		all_kappa_2s = all_kappa;
		all_kappa_3s = all_kappa;

		l = find( all_kappa_p > alpha_kappa_3s );
		all_kappa_3s(l) = NaN;
		l = find( all_kappa_p > alpha_kappa_2s );
		all_kappa_2s(l) = NaN;
		l = find( all_kappa_p > alpha_kappa_1s );
		if plot_1s
			all_kappa_1s(l) = NaN;
		else
			all_kappa_1s(:) = NaN;
		end
		% the matrices have a row of zero values

		all_kappa_1s(12,:) = [];
		all_kappa_2s(12,:) = [];
		all_kappa_3s(12,:) = [];
		model_name_list(12) = [];

		% removes the row of NaNs that separates the two subensembles
		model_name_list_label(12) = [];
		if exist('ta_cooling','var')
			ta_cooling(12) = [];
		end

		kappa_by_region_and_model_1s(mm,:) = squeeze(max(all_kappa_1s(:,5:end)'));
		kappa_by_region_and_model_2s(mm,:) = squeeze(max(all_kappa_2s(:,5:end)'));
		kappa_by_region_and_model_3s(mm,:) = squeeze(max(all_kappa_3s(:,5:end)'));

	end

	kappa_by_region_and_model_1s(isnan(kappa_by_region_and_model_1s)) = 0;
	kappa_by_region_and_model_2s(isnan(kappa_by_region_and_model_2s)) = 0;
	kappa_by_region_and_model_3s(isnan(kappa_by_region_and_model_3s)) = 0;

	min_ta_cooling = min(ta_cooling);
	max_ta_cooling = max(ta_cooling);

	i_ems = [ 11 20 ];

	i_models = 1 : size(kappa_by_region_and_model_3s,2);
	i_models(i_ems) = [];

	kappa_by_region_and_model_1s_all(nn,:,:) = kappa_by_region_and_model_1s(:,i_ems);

	subplot(2,3,nn)
	spider_plot(kappa_by_region_and_model_1s(:,i_ems)','AxesLimits',[0 0 0 0 0; 1 1 1 1 1],...
		'AxesLabels',proxy_type_desc_label_list,...
		'LabelFontSize',14,'AxesLabelsEdge','none')
		%'AxesLabels',region_list_label)
	title(region_list_label{nn},'FontSize',20)
	if nn == 2
		h = legend('EM of cooling models','EM of muted cooling models');
        	set(h,'fontSize',15)
		set(h,'box','off')
        	legPos = get(h,'Position');
        	set(h,'Position',legPos + [ -.16 .04 0 0 ])
	end

end

set(gcf,'Position',[ 1 40 1500 950 ])
pdf_file = [ get_paper_fig_dir '/Figure5.pdf'];
exportgraphics(gcf,pdf_file,'BackgroundColor','none','ContentType','vector')
