function [ raw, grid ] = get_grid_proxy_2024( proxy_file, orig_cat, rad, lon_r, lat_r, proxy_type_exclude, exclude_record_by_id )
% [ raw, grid ] = get_grid_proxy_2024( proxy_file, orig_cat, rad, lon_r, lat_r, proxy_type_exclude, exclude_record_by_id )

if nargin == 3
	lon_r = [ -inf inf ];
	lat_r = lon_r;
end

xls_file = proxy_file;
proxy_data = readtable(xls_file,ReadVariableNames=false);

raw.id = table2array(proxy_data(:,1));
raw.lat = table2array(proxy_data(:,5));
raw.lon = table2array(proxy_data(:,6));
raw.proxy_type = table2array(proxy_data(:,8));
if orig_cat
	raw.val = table2array(proxy_data(:,12));
	same_as_original = table2array(proxy_data(:,13));
else
	raw.val = table2array(proxy_data(:,7));
end

k = find( ~isnan(raw.val) );
raw.id = raw.id(k);
raw.val = raw.val(k);
raw.lon = raw.lon(k);
raw.lat = raw.lat(k);
raw.proxy_type = raw.proxy_type(k);

raw.is_robust = ones(size(raw.val));
raw.n_obs = ones(size(raw.lon));

if length(lon_r) == 2 & length(lat_r) == 2
	lon_r = [ lon_r 0 0 0 0 0 0 0 0 0 0 ]; lat_r = [ lat_r 0 0 0 0 0 0 0 0 0 0 ]; % this way the next line won't crash
end
if length(lon_r) == 4 & length(lat_r) == 4
	lon_r = [ lon_r 0 0 0 0 0 0 0 0 ]; lat_r = [ lat_r 0 0 0 0 0 0 0 0 ]; % this way the next line won't crash
end
if length(lon_r) == 6 & length(lat_r) == 6
	lon_r = [ lon_r 0 0 0 0 0 0 ]; lat_r = [ lat_r 0 0 0 0 0 0]; % this way the next line won't crash
end
if length(lon_r) == 8 & length(lat_r) == 8
	lon_r = [ lon_r 0 0 0 0 ]; lat_r = [ lat_r 0 0 0 0 ]; % this way the next line won't crash
end
if length(lon_r) == 10 & length(lat_r) == 10
	lon_r = [ lon_r 0 0 ]; lat_r = [ lat_r 0 0 ]; % this way the next line won't crash
end

k1 = find( raw.val > -90 & ( ...
	( raw.lon >= lon_r(1) & raw.lon <= lon_r(2) & raw.lat >= lat_r(1) & raw.lat <= lat_r(2) ) | ...
	( raw.lon >= lon_r(3) & raw.lon <= lon_r(4) & raw.lat >= lat_r(3) & raw.lat <= lat_r(4) ) | ...
	( raw.lon >= lon_r(5) & raw.lon <= lon_r(6) & raw.lat >= lat_r(5) & raw.lat <= lat_r(6) ) | ...
	( raw.lon >= lon_r(7) & raw.lon <= lon_r(8) & raw.lat >= lat_r(7) & raw.lat <= lat_r(8) ) | ...
	( raw.lon >= lon_r(9) & raw.lon <= lon_r(10) & raw.lat >= lat_r(9) & raw.lat <= lat_r(10) ) |  ...
	( raw.lon >= lon_r(11) & raw.lon <= lon_r(12) & raw.lat >= lat_r(11) & raw.lat <= lat_r(12) )   ...
) );

if proxy_type_exclude > 0
	if proxy_type_exclude < 9
		k2 = find( raw.proxy_type(k1) ~= proxy_type_exclude );
	else
		if proxy_type_exclude < 99
			aux = num2str(proxy_type_exclude);
			proxy_type_exclude1 = str2num(aux(1));
			proxy_type_exclude2 = str2num(aux(2));
			disp( [ proxy_type_exclude1 proxy_type_exclude2 ])
			k2 = find( raw.proxy_type(k1) ~= proxy_type_exclude1 & raw.proxy_type(k1) ~= proxy_type_exclude2 );
		else
			aux = num2str(proxy_type_exclude);
			proxy_type_exclude1 = str2num(aux(1));
			proxy_type_exclude2 = str2num(aux(2));
			proxy_type_exclude3 = str2num(aux(3));
			disp( [ proxy_type_exclude1 proxy_type_exclude2 proxy_type_exclude3])
			k2 = find( raw.proxy_type(k1) ~= proxy_type_exclude1 & raw.proxy_type(k1) ~= proxy_type_exclude2 & raw.proxy_type(k1) ~= proxy_type_exclude3 );
		end
	end
else
	k2 = 1 : length(k1);
end

k = k1(k2);

if ~isempty(exclude_record_by_id)
	for ll = 1 : length(exclude_record_by_id)
		k3 = find( raw.id(k) ~= exclude_record_by_id(ll) );
		k = k(k3);
	end
end

[ lon, lat, val, n_obs, is_robust, proxy_type ] = grid_proxy( raw.lon(k), raw.lat(k), raw.val(k), rad, raw.n_obs(k), raw.is_robust(k), raw.proxy_type(k) );
[ lon, lat, val, n_obs, is_robust, proxy_type ] = grid_proxy( lon, lat, val, rad+10, n_obs, is_robust, proxy_type );

grid.lon = lon;
grid.lat = lat;
grid.val = val;
grid.n_obs = n_obs;
grid.is_robust = is_robust;

raw.id = raw.id(k);
raw.proxy_type = raw.proxy_type(k);
raw.lon = raw.lon(k);
raw.lat = raw.lat(k);
raw.val = raw.val(k);
raw.n_obs = raw.n_obs(k);
raw.is_robust = raw.is_robust(k);
%raw.proxy_type = raw.proxy_type(k);

function [ lon, lat, val, n_obs, is_robust, proxy_type ] = grid_proxy( lon, lat, val, rad, n_obs, is_robust, proxy_type )
%

lon = lon(:);
lat = lat(:);
val = val(:);
is_robust = is_robust(:);
proxy_type = proxy_type(:);

%if nargin == 4
%	is_robust = ones(size(lon));
%	n_obs = ones(size(lon));
%end

lat1 = []; lon1 = []; val1 = []; is_robust1 = []; n_obs1 = []; proxy_type1 = [];
lonm = []; latm = []; valm = []; is_robustm = []; n_obsm = []; proxy_typem = [];

% I need to add a second loop to check that the merged proxies are not already close
% work with del

for k = 1 : length( lon )

	lon_b = lon(k); lat_b = lat(k); proxy_type_b = proxy_type(k);

	d = distance2([ lat repmat(lat_b,size(lat)) ],[ lon repmat(lon_b,size(lon)) ]);

	%if lat(k) == -19 & lon(k) == -67
	%	keyboard
	%end

	%l = find( d > 0  & d <= rad );
	l = find( d >= 0  & d <= rad & proxy_type == proxy_type_b );
	if ~isempty(l) & length(l) > 1
		latm = [ latm nanmean(lat(l)) ];
		lonm = [ lonm nanmean(lon(l)) ];
		if length(unique(sign(val(l)))) == 1 & ( sum(is_robust(l)) == length(l) | sum(isnan(is_robust(l))) == length(l) )
			is_robust_b = 1;
			val_b = nanmean(val(l));
		else
			is_robust_b = 0;
			val_b = 0;
		end
		is_robustm = [ is_robustm is_robust_b ];
		valm = [ valm val_b ];
		n_obsm = [ n_obsm length(l) ];
		proxy_typem = [ proxy_typem proxy_type_b ];
	else
		lat1 = [ lat1 lat(k) ];
		lon1 = [ lon1 lon(k) ];
		val1 = [ val1 val(k) ];
		is_robust1 = [ is_robust1 is_robust(k) ];
		n_obs1 = [ n_obs1 n_obs(k) ];
		proxy_type1 = [ proxy_type1 proxy_type(k) ];
	end

end

del = unique([ lonm; latm; valm; is_robustm; n_obsm; proxy_typem ]','rows');

if ~isempty(del)
	lonm = del(:,1)';
	latm = del(:,2)';
	valm = del(:,3)';
	is_robustm = del(:,4)';
	n_obsm = del(:,5)';
	proxy_typem = del(:,6)';
else
	lonm = [];
	latm = [];
	valm = [];
	is_robustm = [];
	n_obsm = [];
	proxy_typem = [];
end
lon = [ lon1 lonm ];
lat = [ lat1 latm ];
val = [ val1 valm ];
is_robust = [ is_robust1 is_robustm ];
n_obs = [ n_obs1 n_obsm ];
proxy_type = [ proxy_type1 proxy_typem ];
