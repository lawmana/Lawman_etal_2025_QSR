function proj_root_dir = get_proj_root_dir

proj_root_dir = '.';
