function M = build_proxy_model_matrix( proxy, model )

	% model-proxy

	
	%	              PROXY 
	% 
	%       | dry-dry 		    dry-wet
	% MODEL |            unchg-unchg
	%       | wet-dry                   wet-wet
	%	

	% main diagonal contains the agrement
	% dry-dry
	M(1,1) = length( find( model == -1 & proxy == -1 ));
	% nochange-nochange
	M(2,2) = length( find( model == 0 & proxy == 0 ));
	% wet-wet
	M(3,3) = length( find( model == 1 & proxy == 1 ));
                
	% dry-wet
	M(3,1) = length( find( model == -1 & proxy == 1 ));
	% wet-dry
	M(1,3) = length( find( model == 1 & proxy == -1 ));

	% dry model - unchg proxy
	M(2,1) = length( find( model == -1 & proxy == 0 ));
	% wet model - unchg proxy
	M(2,3) = length( find( model == 1 & proxy == 0 ));

	% unchg model - dry proxy
	M(1,2) = length( find( model == 0 & proxy == -1 ));
	% unchg model - wet proxy
	M(3,2) = length( find( model == 0 & proxy == 1 ));

