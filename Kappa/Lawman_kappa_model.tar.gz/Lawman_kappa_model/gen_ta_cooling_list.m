function gen_ta_cooling_list
% gen_ta_cooling_list

[ pr_hose, pr, tas_hose, tas_ctl, lon, lat, model_name_list, model_name_list_label, lgm_amoc, hose_amoc ] = get_hose_data_new;

topo = load([ get_proj_root_dir '/etopo5.360lon.mat']);
% shift lon from 0/360 to -180/180
k_p = find( topo.lon <= 180 );
k_n = find( topo.lon > 180 & topo.lon < 360 );
topo.lon180 = [ topo.lon(k_n)-360 topo.lon(k_p) ];
topo.topo180 = [ topo.topo(k_n,:); topo.topo(k_p,:) ];
topo_i = interp2(topo.lon180,topo.lat,topo.topo180',lon,lat');
topo_b = permute(repmat(topo_i,[1 1 size(tas_hose,1)]),[3 1 2]);
land_mask = ones(size(topo_b));
k = find( topo_b < 0 );
land_mask(k) = NaN;
ocean_mask = ones(size(topo_b));
k = find( topo_b > -200 );
ocean_mask(k) = NaN;
ocean_mask = permute(ocean_mask,[1 3 2]);

tos_hose = tas_hose.*ocean_mask;

ta_r = [ -80 -40 12 22 ];
ta_cooling = get_area_ts(tos_hose,lon,lat,ta_r);

ta_cooling_lim = -1;
ta_cooling_lim_strong = -3;

na_r = [ -60 0 40 65 ];
na_cooling = get_area_ts(tas_hose.*ocean_mask,lon,lat,na_r);

save('ta_cooling_models_2025.mat','ta_cooling','model_name_list','model_name_list_label','ta_cooling_lim_strong','ta_cooling_lim','na_cooling')
