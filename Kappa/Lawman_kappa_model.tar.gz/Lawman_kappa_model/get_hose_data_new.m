function [ pr_hose, pr, tas_hose, tas, lon, lat, model_name_list, model_name_list_label, lgm_amoc, hose_amoc, hose_fw ] = get_hose_data_new
% [ pr_hose, pr, tas_hose, tas, lon, lat, model_name_list, model_name_list_label, lgm_amoc, hose_amoc, hose_fw ] = get_hose_data_new

load hose_data_new.mat
