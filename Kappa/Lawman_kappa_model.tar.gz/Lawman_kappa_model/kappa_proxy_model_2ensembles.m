clear
%
compilation_version = '2025';
%
orig_interp_drywet = 0; % this option will use our new intepretation for a subset of records
% orig_interp_drywet = 1; % this option will use the original published interpretation
%
% proxy types to include the comparison
% coded to exclude a type
% this selection of proxy types was used in the Nature paper
%
proxy_type_desc_list = { 'all' 'nomariso' 'aridity_terriso' 'aridity_veg' 'terriso_veg' };

for nnn = 1:length(proxy_type_desc_list)

	proxy_type_desc = proxy_type_desc_list{nnn};

	switch proxy_type_desc
		case 'terriso_veg'
			proxy_type_exclude = 24; % selects 1 & 3
		case 'aridity_veg'
			proxy_type_exclude = 14; % selects 2 & 3
		case 'aridity_terriso'
			proxy_type_exclude = 43; % selects 1 & 2
		case 'nomariso'
			proxy_type_exclude = 4;
		case 'all'
			proxy_type_exclude = 0;
	end
		
%
%
% FINAL FIVE REGIONS used in the Nature paper:
%
region_name_list = { 'Global' 'GlobalNoAtlanticITCZ' 'AtlanticITCZ' 'PacificITCZ' 'IOMonsoons' 'WalkerCirculation' };
%
% Definition of subensembles based on the magnitude of cooling over the tropical N. Atlantic
trop_cooling_ensembles = { 'MMEM-TATLCooling' 'MMEM-NoTATLCooling' };
trop_cooling_ensembles_ranges = { [ -inf -1 ] [ -1 inf ] };
%
% the following variables help define the domain where the proxy-model comparison is performed
% values are set to those used in the Science paper
% latitude of the southern boundary of all domains
SHLL = -25;

% weights used for near matchs in kappa calculation
kappa_method = 0; % 0 weights for near matches
kappa_method = 7; % 0.5 weights for near matches, used in DNT13

terr_rad = 100; % radius in km to merge nearby records
pmip_var_name = 'pr'; % name of rainfall variable in models
var_name = 'P'; % name of rainfall variable in plots
norm_dPP = 1; % normalize model output for comparison with proxies, ie convert rainfall change to % change
dPP_lim = 1 : 1 : 100; % thresholds used to define dry/unch/wet categories

% alpha for plotting statistical significance of kappa
% p is also computed and saved
alpha = .33;

% list of records to exclude
exclude_record_by_id = [];

%%%------------------ END OF INPUT PARAMETERS ----------------------
%%%------------------ MODIFY AT YOUR OWN RISK ----------------------

pmip_clim_dir = get_proj_root_dir;
proxy_dir = get_proj_root_dir;
data_dir = [  get_proj_root_dir '/kappa_data' ];
unix([ 'mkdir -p ' get_fig_dir ';' ]);
%
plot_perLim = [ 1 65 ];
ax = [];

letter_label_list = { 'A' 'B' 'C' 'D' 'E' 'F' };
figure(2); clf;
set(gcf,'Position',[ 1 55 1450 780]);

subplot_i = [ 1 2 3 4 5 6 ];
for plot_k = 1:length(region_name_list)
	plot_i = subplot_i(plot_k);
	region_name = region_name_list{plot_k};

switch region_name

	case 'Global'
		kappa_fig_title = 'Global';
		proxy_lon_r = [ -180 20 20   80 80   100 95 120 100  150 ];
                proxy_lat_r = [ -28  35 SHLL 40 SHLL 31  5  30  SHLL 25 ];

	case 'IOMonsoons'
		% monsoon regions of east Africa, India, and Australia
		kappa_fig_title = 'East African, Indian & Australian monsoons';
		proxy_lon_r = [   20 80 80 100 95 120 90 110   80 130 ];
		proxy_lat_r = [ SHLL 31  9  40 10  30 -5  10 SHLL  -7 ];

	case 'WalkerCirculation'
		kappa_fig_title = 'Pacific Walker Circulation';
		proxy_lon_r = [ -160 -120 -120 -66 110 130 110 125 125 130 130 150];
		proxy_lat_r = [ -5     25 -40   -1  -5  20 -5    8 -8 0 -20 10 ];

	case 'PacificITCZ'
		kappa_fig_title = 'Caribbean and Eastern Pacific ITCZ';
		proxy_lon_r = [ -120 -66 ];
		proxy_lat_r = [ SHLL 40 ];

	case 'AtlanticITCZ'
		kappa_fig_title = 'Atlantic ITCZ';
		proxy_lon_r = [  -66 0 0 20 ];
		proxy_lat_r = [ -28 35 SHLL 35 ];

	case 'GlobalNoAtlanticITCZ'
		kappa_fig_title = 'Global (no Atlantic)';
		proxy_lon_r = [ -180 -70   20 60   60 80   80 100 95 120  100 150 ];
		proxy_lat_r = [ -28  30 SHLL 30 SHLL 35 SHLL  31 10  25 SHLL  25 ];

end

% order the model list based on the magnitude of tropical Atlantic cooling
gen_ta_cooling_list
model_ta_cooling = load('ta_cooling_models_2025.mat');
[ model_ta_cooling_sorted, l ] = sort(model_ta_cooling.ta_cooling);
model_name_list = model_ta_cooling.model_name_list(l);
model_name_list_label = model_ta_cooling.model_name_list_label(l);
for m = 1 : length(model_name_list_label)
	model_name_list_label{m} = [ num2str(m) '.' model_name_list_label{m} ];
	model_name_list_label_num{m} = [ num2str(m) ];
end

save('ta_cooling_models_2025.mat','-append','trop_cooling_ensembles_ranges','trop_cooling_ensembles');

model_name_list_b = model_name_list;
model_name_list_label_b = model_name_list_label;
model_name_list_label_num_b = model_name_list_label_num;
model_name_list = {};
model_name_list_label = {};
model_name_list_label_num = {};
for ll = 1:length(trop_cooling_ensembles)

	cooling_r = trop_cooling_ensembles_ranges{ll};
	mm = find( model_ta_cooling_sorted > cooling_r(1) & model_ta_cooling_sorted < cooling_r(2) );
	model_name_list = [ model_name_list {model_name_list_b{mm}} trop_cooling_ensembles{ll} 'empty' ];
	model_name_list_label = [ model_name_list_label {model_name_list_label_b{mm}} 'Ensemble mean' {''} ];
	model_name_list_label_num = [ model_name_list_label_num {model_name_list_label_num_b{mm}} 'EM' {''} ];
end
model_name_list = {model_name_list{1:end-1}};
model_name_list_label = {model_name_list_label{1:end-1}};

min_dPP_lim = 0;

% range of lons and lats used to plot maps
ps_lon_r = [ -180 180 ];
ps_lat_r = 45*[ -1 1 ];

% in the 2013 paper we ran the kappa for different seasons
% we cannot do that with the hosing experiments because we only have annmean
model_clim = 'SON';
model_clim = 'annmean';

% this was used in our 2013 paper to run the same analysis for records with better chrnologies (chrono_flag=1)
% so keep at chrono_flag=0
chrono_flag = 1;
chrono_flag = 0;

[ raw, grid ] = get_grid_proxy_2025( [ proxy_dir '/DiNezio_etal_HS1_database_' compilation_version '.xlsx' ], orig_interp_drywet, terr_rad, proxy_lon_r, proxy_lat_r, proxy_type_exclude, exclude_record_by_id );

plot_proxy_sites_map;

all_per = [];
all_per_is_rob = [];
all_kappa = [];
all_pe = [];
all_po = [];
all_kappa_sig = [];

pr_diff_all = [];
pr_diffp_all = [];
dPPi_all = [];
ta_cooling = [];
lgm_amoc = [];
hose_amoc = [];

for m = 1 : length( model_name_list ) 

	model = model_name_list{m};
	
	[ dPP, lon, lat, dPPi, pr_diff, tas_data, amoc_data ] = get_model_lgm_var_change_2025(  model, model_clim, pmip_var_name, grid.lat, grid.lon, dPP_lim, norm_dPP );
	%if isempty(findstr(model,'MMEM'))
		ta_cooling(m) = nanmean(tas_data.ta_cooling);
		lgm_amoc(m) = nanmean(amoc_data.lgm_amoc);
		hose_amoc(m) = nanmean(amoc_data.hose_amoc);
	%end

	pr_diff_all(m,:,:) = pr_diff;
	pr_diffp_all(m,:,:) = dPP;
	dPPi_all(m,:,:) = dPPi;

	for l = 1 : length( dPP_lim )

		n_per = length(find(sign(grid.val)==sign(dPPi(l,:))));
		n_tot = length(dPPi(l,:));
		per = n_per./n_tot*100;
		n_per = length(find(sign(grid.val)==sign(dPPi(l,:)) & grid.is_robust >= 1));
		n_tot = length(find(grid.is_robust >= 1 ));
		per_is_rob = n_per./n_tot*100;

		all_per(m,l) = per;
		all_per_is_rob(m,l) = per_is_rob;

		% computes Kappa
		k = find( grid.is_robust > 0 );
		pp = sign(grid.val(k));
        	mm = dPPi(l,k);
		M = build_proxy_model_matrix( pp, mm );
		[ po, pe, ka, sek, ci, km, ratio, p ] = kappa( M, kappa_method, alpha );
		all_kappa(m,l) = ka;
		all_kappa_p(m,l) = p;
		if ci(1) > 0
			all_kappa_sig(m,l) = 1;
		else
			all_kappa_sig(m,l) = 0;
		end
		%all_kappa_sig(m,l) = length(find(p >= alpha ));
		all_po(m,l) = po;
		all_pe(m,l) = pe;

	end

	switch pmip_var_name
		case 'pr'	
			k = find( dPP_lim >= min_dPP_lim & squeeze(all_kappa_p(m,:)) <= alpha );
			if isempty(k)
				k = find( dPP_lim >= min_dPP_lim );
			end
		case 'sos'	
			k = find( dPP_lim >= .5 );
			k = find( dPP_lim >= .1 );
	end
	[ a, b ]= max( all_kappa(m,k) );
	l = k(b);

	n_per = length(find(sign(grid.val)==sign(dPPi(l,:)) & grid.is_robust >= 1));
	n_tot = length(find(grid.is_robust >= 1 ));
	per_is_rob = n_per./n_tot*100;
	k = find( grid.is_robust > 0 );
	pp = sign(grid.val(k));
        mm = dPPi(l,k);
	M = build_proxy_model_matrix( pp, mm );
	[ po, pe, ka, sek, ci, km, ratio, p ] = kappa( M, kappa_method, alpha );
	agrees = zeros(size(grid.lat));
	kk = find( grid.is_robust > 0 & sign(grid.val) == dPPi(l,:) );
	agrees(kk) = 1;
	kk = find( grid.is_robust > 0 & abs(sign(grid.val) -  dPPi(l,:)) == 1 );
	agrees(kk) = .5;

	if ka < 0
		ka = 0; sek = 0; ci = [ 0 0 ]; km = 0; p = 1;
	end

end

k = find( all_kappa < 0 );
all_kappa(k) = 0;
all_kappa_p(k) = 1;
all_kappa_sig(k) = 0;

% this mat file is used in the spider plots
if orig_interp_drywet
	file_desc_add = 'origdrywet';
else
	file_desc_add = 'newdrywet';
end
kappa_mat_file = sprintf('%s/%s_%s_%s_kappa.mat',data_dir,region_name,proxy_type_desc,file_desc_add);
unix([ 'mkdir -p ' data_dir ';' ]);
save(kappa_mat_file,'all_kappa','all_kappa_p','all_kappa_sig','model_name_list','model_name_list_label','ta_cooling','grid','dPPi_all','raw');

figure(2);
ax(plot_i) = subplot(3,2,plot_i);
plot_model_name_labels = 0;
if plot_i <=2
	plot_model_name_labels = 1;
end

plot_kappa_thresholds;

title(kappa_fig_title,'fontSize',16)
text(-2.3,69.5,letter_label_list{plot_k},'fontSize',20)
axPos(plot_i,:) = get(ax(plot_i),'Position');

end

%set(ax(1),'Position',axPos(1,:)+[.21 .05 0 0 ])
if length(region_name_list) > 1
	if length(subplot_i)>=3
		set(ax(3),'Position',axPos(3,:)+[0 -.096 0 0 ])
		set(ax(4),'Position',axPos(4,:)+[0 -.096 0 0 ])
	end
	if length(subplot_i)>=5
		set(ax(5),'Position',axPos(5,:)+[0 -.08 0 0 ])
		set(ax(6),'Position',axPos(6,:)+[0 -.08 0 0 ])
	end
end

ax3pos = get(ax(1),'Position');
axxlen = ax3pos(3)*.95;
for mm = 1:6
	axPos_b = get(ax(mm),'Position');
	axPos_b(3) = axxlen;
	set(ax(mm),'Position',axPos_b);
end

figure(2);
set(gcf,'Position',[ 1         555        1112         800 ])
if length(region_name_list) == 1
	pdf_file = sprintf('%s/kappa_thresholds_%s_%s.pdf',get_fig_dir,region_name,proxy_type_desc);
else
	pdf_file = sprintf('%s/kappa_thresholds_by_region_%s.pdf',get_fig_dir,proxy_type_desc);
end

exportgraphics(gcf,pdf_file,'BackgroundColor','none','ContentType','vector')

end
